# Dana Point Disco — v18 (Hero MUCH Bigger + No Deletions)

- Enlarged hero overlay dramatically (`width: clamp(1600px, 95vw, 2800px); right: -8vw`) to match the mock.
- Keeps: Events section, Sunset visual, VW bus/daisy image in About, copy updates.
- No deletions or renames. Safe to drop in and deploy.

## Deploy
1. Create a new GitHub repo and **add a README** (initial commit on `main`).
2. Upload all files to the repo root → **Commit directly to main**.
3. Import into Vercel → Deploy.
